package net.realityradio.eden.infrastructure;

import com.mojang.serialization.MapCodec;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.BlockHitResult;
import net.realityradio.eden.Eden;

public final class NetworkNodeBlock extends BaseEntityBlock {
  public static final BooleanProperty ONLINE = BooleanProperty.create("online");
  public static final MapCodec<NetworkNodeBlock> CODEC = simpleCodec(NetworkNodeBlock::new);

  public NetworkNodeBlock(Properties p) {
    super(p);
    registerDefaultState(stateDefinition.any().setValue(ONLINE, false));
  }

  protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
    b.add(ONLINE);
  }

  protected MapCodec<? extends BaseEntityBlock> codec() {
    return CODEC;
  }

  protected RenderShape getRenderShape(BlockState s) {
    return RenderShape.MODEL;
  }

  public BlockEntity newBlockEntity(BlockPos p, BlockState s) {
    return new NetworkNodeEntity(p, s);
  }

  public <T extends BlockEntity> BlockEntityTicker<T> getTicker(
      Level l, BlockState s, BlockEntityType<T> t) {
    return l.isClientSide
        ? null
        : createTickerHelper(t, Eden.NETWORK_ENTITY.get(), NetworkNodeEntity::tick);
  }

  public void setPlacedBy(Level l, BlockPos p, BlockState s, LivingEntity who, ItemStack stack) {
    if (l.getBlockEntity(p) instanceof NetworkNodeEntity n) {
      var d = stack.get(DataComponents.CUSTOM_DATA);
      if (d != null && d.contains("eden_node"))
        n.loadWithComponents(d.copyTag().getCompound("eden_node"), l.registryAccess());
      if (n.owner == null) n.owner = who == null ? null : who.getUUID();
      n.setChanged();
    }
  }

  protected List<ItemStack> getDrops(BlockState s, LootParams.Builder p) {
    var drops = super.getDrops(s, p);
    if (p.getOptionalParameter(LootContextParams.BLOCK_ENTITY) instanceof NetworkNodeEntity n) {
      var tag = new net.minecraft.nbt.CompoundTag();
      tag.put("eden_node", n.saveWithoutMetadata(p.getLevel().registryAccess()));
      for (var stack : drops)
        if (stack.getItem() instanceof net.minecraft.world.item.BlockItem b && b.getBlock() == this)
          stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }
    return drops;
  }

  protected InteractionResult useWithoutItem(
      BlockState s, Level l, BlockPos p, Player who, BlockHitResult h) {
    if (who instanceof ServerPlayer player && l.getBlockEntity(p) instanceof NetworkNodeEntity n) {
      if (Set.of("rack", "charger").contains(n.kind())
          && player.isShiftKeyDown()
          && (player.hasPermissions(2) || player.getUUID().equals(n.owner)))
        player.openMenu(
            new SimpleMenuProvider(
                (id, inv, w) ->
                    new net.minecraft.world.inventory.ChestMenu(
                        net.minecraft.world.inventory.MenuType.GENERIC_9x1,
                        id,
                        inv,
                        new RackContainer(n),
                        1),
                net.minecraft.network.chat.Component.literal(
                    n.kind().equals("charger")
                        ? "Charging Station · Phones & Batteries"
                        : "Server Rack · Data Cartridges")));
      else NodeNetworking.open(player, n);
    }
    return InteractionResult.sidedSuccess(l.isClientSide);
  }
}
